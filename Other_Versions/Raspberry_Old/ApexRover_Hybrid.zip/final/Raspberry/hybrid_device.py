import time
import threading
import serial
import requests
from typing import Optional
from collections import deque
from config import SERIAL_TIMEOUT, SERIAL_WRITE_TIMEOUT, ESP32_HTTP_TIMEOUT


class HybridDevice:
    """
    Two-channel communication device for Mega and UNO.

    SEND path  :  Raspberry Pi  ->  HTTP POST /command  ->  ESP32  ->  Arduino
    READ path  :  Raspberry Pi  <-  USB Serial direct   <-  Arduino

    Why hybrid?
      The ESP32 forwards commands to the Arduinos over HardwareSerial but
      cannot relay their replies back to the Pi in real time over HTTP.
      By keeping a direct USB cable for reads we get full two-way comms
      without changing the routing logic on the ESP32 or the Arduinos.

    The Arduino firmware already supports this:
      - Mega:  when ESP32 sends GET:SENSORS, Mega replies on USB Serial (Serial)
               not back to ESP32 (Serial1).
      - UNO:   when ESP32 sends CAM:STATUS / GET:CAMERA, UNO replies on USB
               Serial, not back to ESP32 SoftwareSerial.

    Public API is identical to SerialDevice and EspBridge:
        device.connect()
        device.send("FORWARD")
        line = device.read_line()
        device.close()
    """

    def __init__(
        self,
        name: str,
        esp32_ip: str,
        serial_port: str,
        baud_rate: int = 9600,
        http_timeout: float = ESP32_HTTP_TIMEOUT,
    ):
        self.name         = name
        self.esp32_ip     = esp32_ip.rstrip("/")
        self.serial_port  = serial_port
        self.baud_rate    = baud_rate
        self.http_timeout = http_timeout

        self._cmd_url = f"http://{self.esp32_ip}/command"

        # USB Serial — used ONLY for reading replies from the Arduino.
        self._serial: Optional[serial.Serial] = None
        self._serial_lock = threading.Lock()

        # Non-blocking receive queue filled by the background reader thread.
        self._rx_queue: deque = deque(maxlen=64)
        self._rx_lock   = threading.Lock()

        self._stop_reader  = threading.Event()
        self._reader_thread: Optional[threading.Thread] = None

        self._connected = False

    # ------------------------------------------------------------------
    # Connect: open USB Serial and start the background reader thread.
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        try:
            self._serial = serial.Serial(
                port          = self.serial_port,
                baudrate      = self.baud_rate,
                timeout       = SERIAL_TIMEOUT,
                write_timeout = SERIAL_WRITE_TIMEOUT,
            )
            # Wait for Arduino auto-reset after DTR toggle.
            time.sleep(2)

            try:
                self._serial.reset_input_buffer()
                self._serial.reset_output_buffer()
            except Exception:
                pass

            self._stop_reader.clear()
            self._reader_thread = threading.Thread(
                target = self._reader_loop,
                name   = f"HybridReader-{self.name}",
                daemon = True,
            )
            self._reader_thread.start()

            self._connected = True
            print(f"[OK] {self.name}: USB read  <- {self.serial_port}")
            print(f"[OK] {self.name}: HTTP send -> {self._cmd_url}")
            return True

        except Exception as e:
            print(f"[ERROR] {self.name}: cannot open {self.serial_port} — {e}")
            self._serial    = None
            self._connected = False
            return False

    def is_connected(self) -> bool:
        return (
            self._connected
            and self._serial is not None
            and self._serial.is_open
        )

    def close(self):
        self._stop_reader.set()
        try:
            if self._serial and self._serial.is_open:
                self._serial.close()
        except Exception:
            pass
        self._connected = False
        print(f"[OK] {self.name}: closed")

    # ------------------------------------------------------------------
    # Background thread — continuously drains USB Serial into the queue.
    # ------------------------------------------------------------------

    def _reader_loop(self):
        while not self._stop_reader.is_set():
            try:
                with self._serial_lock:
                    waiting = (
                        self._serial is not None
                        and self._serial.is_open
                        and self._serial.in_waiting > 0
                    )
                    if waiting:
                        raw = self._serial.readline()
                    else:
                        raw = b""

                if raw:
                    line = raw.decode(errors="ignore").strip()
                    if line:
                        with self._rx_lock:
                            self._rx_queue.append(line)
                else:
                    # Avoid busy-spinning when nothing is coming in.
                    time.sleep(0.002)

            except Exception as e:
                print(f"[WARN] {self.name} reader error: {e}")
                time.sleep(0.05)

    # ------------------------------------------------------------------
    # SEND — goes through ESP32 HTTP.
    # The Arduino firmware routes the reply back over USB Serial,
    # which the reader thread will pick up automatically.
    # ------------------------------------------------------------------

    def send(self, command: str) -> bool:
        command = command.strip()
        if not command:
            return False

        print(f"[SEND via ESP32 -> {self.name}] {command}")

        try:
            r = requests.post(
                self._cmd_url,
                data    = {"cmd": command},
                timeout = self.http_timeout,
            )
            if r.status_code == 200:
                return True

            print(f"[WARN] {self.name}: HTTP {r.status_code} for cmd={command}")
            return False

        except requests.exceptions.Timeout:
            print(f"[WARN] {self.name}: HTTP timeout cmd={command}")
            return False
        except Exception as e:
            print(f"[ERROR] {self.name}: send failed — {e}")
            return False

    # ------------------------------------------------------------------
    # READ — pop one line from the queue (filled by the reader thread).
    # Returns None immediately if nothing is available yet.
    # ------------------------------------------------------------------

    def read_line(self) -> Optional[str]:
        with self._rx_lock:
            if self._rx_queue:
                return self._rx_queue.popleft()
        return None

    # ------------------------------------------------------------------
    # fetch_sensors — compatible with EspBridge interface.
    # Sends GET:SENSORS via HTTP; the Mega firmware routes its DATA reply
    # directly to USB Serial, so the reader thread catches it for free.
    # ------------------------------------------------------------------

    def fetch_sensors(self) -> None:
        self.send("GET:SENSORS")
